/*********************************************************************************
 * 
 * Point d'entrée, c'est lui qui intialise le jeu et lance la boucle de jeu. 
 * 
 *********************************************************************************/


/**
 * bouton pour lancer la génération
 */
launch();

/**
 * faire apparaître les métiers en fonction du groupe
 */
afficherSelectionCarriere();

/**
 * bouton pour le mode expert
 */
displayDetailedView();

/**
 * bouton pour le mode expert
 */
displayNotes();


/**
 * champ pour tester si un nouveau prénom est proposé
 */
prenomPersonnalise();

/**
 * change age based on user input
 */

agePersonnalise();


/**
 * bouton pour sauvegarder
 */

takeScreenshotWeb();

